import '@vaadin/vertical-layout/src/vaadin-vertical-layout.js';
import '@vaadin/app-layout/src/vaadin-app-layout.js';
import '@vaadin/horizontal-layout/src/vaadin-horizontal-layout.js';
import '@vaadin/app-layout/src/vaadin-drawer-toggle.js';
import '@vaadin/button/src/vaadin-button.js';
import '@vaadin/tooltip/src/vaadin-tooltip.js';
import 'Frontend/generated/jar-resources/disableOnClickFunctions.js';
import '@vaadin/context-menu/src/vaadin-context-menu.js';
import 'Frontend/generated/jar-resources/flow-component-renderer.js';
import 'Frontend/generated/jar-resources/flow-component-directive.js';
import 'Frontend/generated/jar-resources/vaadin-context-menu/contextMenuConnector.ts';
import 'Frontend/generated/jar-resources/vaadin-context-menu/contextMenuTargetConnector.ts';
import '@vaadin/icons/vaadin-iconset.js';
import '@vaadin/icon/src/vaadin-icon.js';
import '@vaadin/grid/src/vaadin-grid.js';
import '@vaadin/grid/src/vaadin-grid-column.js';
import '@vaadin/grid/src/vaadin-grid-sorter.js';
import '@vaadin/checkbox/src/vaadin-checkbox.js';
import 'Frontend/generated/jar-resources/vaadin-grid/gridConnector.ts';
import 'Frontend/generated/jar-resources/vaadin-grid/vaadin-grid-flow-selection-column.ts';
import '@vaadin/grid/src/vaadin-grid-column-group.js';
import 'Frontend/generated/jar-resources/lit-renderer.ts';
import '@vaadin/text-field/src/vaadin-text-field.js';
import '@vaadin/select/src/vaadin-select.js';
import '@vaadin/dialog/src/vaadin-dialog.js';
import '@vaadin/progress-bar/src/vaadin-progress-bar.js';
import '@vaadin/upload/src/vaadin-upload.js';
import 'Frontend/generated/jar-resources/vaadin-upload/uploadManagerConnector.ts';
import '@vaadin/text-area/src/vaadin-text-area.js';
import '@vaadin/notification/src/vaadin-notification.js';
import '@vaadin/password-field/src/vaadin-password-field.js';
import '@vaadin/common-frontend/ConnectionIndicator.js';
import 'Frontend/generated/jar-resources/ReactRouterOutletElement.tsx';

const loadOnDemand = (key) => {
  const pending = [];
  if (key === 'e67ae2bd4d123585a5c94dab30ba5ffdd494ccac96c1141d6b9f534c219a8ddb') {
    pending.push(import('./chunks/chunk-9ee7e7e4df2cc6375bef81087e89878d337c4cfd502d7972257032d64127716e.js'));
  }
  if (key === '2d50dc41fce50aa52b7e7c2c53bb3a06ef2fbc3d53949168afe1ae819e49d34b') {
    pending.push(import('./chunks/chunk-9ee7e7e4df2cc6375bef81087e89878d337c4cfd502d7972257032d64127716e.js'));
  }
  if (key === 'cc199fc4e93e3ade0055b61c8745f094ec835503aab42ff8007211eb16ecc71c') {
    pending.push(import('./chunks/chunk-9ee7e7e4df2cc6375bef81087e89878d337c4cfd502d7972257032d64127716e.js'));
  }
  if (key === '6e32a6669d92e7ee399e2d0f1dc33f3f1cfd26df5635555bcbace2764821be6e') {
    pending.push(import('./chunks/chunk-9ee7e7e4df2cc6375bef81087e89878d337c4cfd502d7972257032d64127716e.js'));
  }
  return Promise.all(pending);
}

window.Vaadin = window.Vaadin || {};
window.Vaadin.Flow = window.Vaadin.Flow || {};
window.Vaadin.Flow.loadOnDemand = loadOnDemand;
window.Vaadin.Flow.resetFocus = () => {
 let ae=document.activeElement;
 while(ae&&ae.shadowRoot) ae = ae.shadowRoot.activeElement;
 return !ae || ae.blur() || ae.focus() || true;
}